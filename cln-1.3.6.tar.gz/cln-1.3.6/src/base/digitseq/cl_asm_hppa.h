// List the contents of cl_asm_hppa.cc.

