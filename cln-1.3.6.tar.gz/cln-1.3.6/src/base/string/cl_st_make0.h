#ifndef _CL_ST_MAKE0_H
#define _CL_ST_MAKE0_H
#include "cln/string.h"

namespace cln {

extern cl_heap_string* cl_make_heap_string (unsigned long len);

}  // namespace cln

#endif /* _CL_ST_MAKE0_H */
