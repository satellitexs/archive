// Version string buried into the library
#include "cln/version.h"

namespace cln {

const int version_major = CL_VERSION_MAJOR;
const int version_minor = CL_VERSION_MINOR;
const int version_patchlevel = CL_VERSION_PATCHLEVEL;

}  // namespace cln
